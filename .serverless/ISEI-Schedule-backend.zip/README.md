# Schedule-for-ISEU

Ready API for parsing data from the ISEI schedule

Hi men!
