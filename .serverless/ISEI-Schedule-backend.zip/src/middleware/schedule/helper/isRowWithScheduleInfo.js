export default ({ attribs: { class: cl } }) => cl === 'row' || cl === 'row row-spanned';
