export default (el, className) => el?.attribs?.class.includes(className);
